* generate barcode ?
* add more detailed example in demo file to showcase features
* add migration guide aeroo -> py3o
